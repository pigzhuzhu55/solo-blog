title: 我在 GitHub 上的开源项目
date: '2019-11-08 16:52:36'
updated: '2019-11-08 16:52:36'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [CodeSmithTemplates](https://github.com/pigzhuzhu55/CodeSmithTemplates) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/CodeSmithTemplates/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/CodeSmithTemplates/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/CodeSmithTemplates/network/members "分叉数")</span>





---

### 2. [ant-design-cly](https://github.com/pigzhuzhu55/ant-design-cly) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/pigzhuzhu55/ant-design-cly/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/ant-design-cly/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/pigzhuzhu55/ant-design-cly/network/members "分叉数")</span>

基于antd的二次封装



---

### 3. [v2.preview.pro.ant.design.test](https://github.com/pigzhuzhu55/v2.preview.pro.ant.design.test) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/pigzhuzhu55/v2.preview.pro.ant.design.test/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/v2.preview.pro.ant.design.test/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/v2.preview.pro.ant.design.test/network/members "分叉数")</span>

练习antd



---

### 4. [spring.boot-2.1.0-](https://github.com/pigzhuzhu55/spring.boot-2.1.0-) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/pigzhuzhu55/spring.boot-2.1.0-/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/spring.boot-2.1.0-/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/spring.boot-2.1.0-/network/members "分叉数")</span>

shiro(redis|ehcache)



---

### 5. [k8s_jira](https://github.com/pigzhuzhu55/k8s_jira) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/k8s_jira/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/k8s_jira/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/k8s_jira/network/members "分叉数")</span>

基于k8s部署的jira8.1.0



---

### 6. [Design](https://github.com/pigzhuzhu55/Design) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/Design/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/Design/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/Design/network/members "分叉数")</span>

java 设计模式学习



---

### 7. [spring-ioc](https://github.com/pigzhuzhu55/spring-ioc) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/spring-ioc/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/spring-ioc/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/spring-ioc/network/members "分叉数")</span>

学习IOC容器设计与实现



---

### 8. [nginx_spring.boot-demo](https://github.com/pigzhuzhu55/nginx_spring.boot-demo) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/nginx_spring.boot-demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/nginx_spring.boot-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/nginx_spring.boot-demo/network/members "分叉数")</span>

通过docker-composer启动容器nginx，并完成spring.boot的web站点端口转发



---

### 9. [DisConf](https://github.com/pigzhuzhu55/DisConf) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/DisConf/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/DisConf/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/DisConf/network/members "分叉数")</span>

统一配置管理DEMO



---

### 10. [EMailWarnConsole](https://github.com/pigzhuzhu55/EMailWarnConsole) <kbd title="主要编程语言">C#</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pigzhuzhu55/EMailWarnConsole/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pigzhuzhu55/EMailWarnConsole/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pigzhuzhu55/EMailWarnConsole/network/members "分叉数")</span>

站点异常邮件提醒

